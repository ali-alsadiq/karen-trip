//
//  ViewController.swift
//  Group3_Assignment1
//
//  Created by Alex Wang on 2023-05-10.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

